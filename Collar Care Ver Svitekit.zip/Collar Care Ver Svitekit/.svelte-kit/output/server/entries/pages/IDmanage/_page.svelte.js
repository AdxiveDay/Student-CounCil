import { a as attr } from "../../../chunks/attributes.js";
import { c as pop, p as push } from "../../../chunks/index.js";
function _page($$payload, $$props) {
  push();
  let Name = "";
  let Position = "";
  let Class = "";
  let num = void 0;
  let Profile = "";
  let DeleteNum = void 0;
  $$payload.out += `<nav class="flex m-[3rem] items-center justify-between"><ul><h1 class="font-bold text-2xl w-[50px] text-blue-400">Student Council</h1></ul> <ul class="flex"><li class="mr-[1rem]"><a class="text-white" href="/">Point</a></li></ul></nav> <div class="flex justify-center flex-col items-center h-screen m-[3rem]"><div class="bg-blue-400 flex flex-col rounded-2xl items-center p-[1.5rem] w-fit"><h1 Class="font-medium text-3xl text-white m-[1rem]">CreateID</h1> <input type="text" placeholder="Picture Link"${attr("value", Profile)} class="bg-white p-[0.5rem] rounded-md"> <input type="text" placeholder="Number"${attr("value", num)} class="bg-white p-[0.5rem] m-[1rem] rounded-md"> <input type="text" placeholder="name"${attr("value", Name)} class="bg-white p-[0.5rem] rounded-md"> <input type="text" placeholder="Position"${attr("value", Position)} class="bg-white p-[0.5rem] m-[1rem] rounded-md"> <input type="text" placeholder="Class"${attr("value", Class)} class="bg-white p-[0.5rem] mb-[1rem] rounded-md"> <button class="bg-white p-[0.5rem] rounded-md">Add</button></div> <div class="bg-red-400 flex flex-col rounded-2xl items-center p-[1.5rem] mt-[2rem] w-fit"><h1 class="text-white font-md text-4xl">Delete ID</h1> <input type="number" placeholder="ID"${attr("value", DeleteNum)} class="bg-white p-[0.5rem] m-[1rem] rounded-md"> <button class="bg-white p-[0.5rem] rounded-md">ยืนยัน</button></div></div>`;
  pop();
}
export {
  _page as default
};
