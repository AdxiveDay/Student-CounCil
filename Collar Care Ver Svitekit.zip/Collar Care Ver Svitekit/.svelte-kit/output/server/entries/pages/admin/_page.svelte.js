import { a as attr } from "../../../chunks/attributes.js";
import { c as pop, p as push } from "../../../chunks/index.js";
function _page($$payload, $$props) {
  push();
  let Num = void 0;
  let PointChange = void 0;
  $$payload.out += `<nav class="flex m-[3rem] items-center justify-between"><ul><h1 class="font-bold text-2xl w-[50px] text-blue-400">Student Council</h1></ul> <ul class="flex"><li class="mr-[1rem]"><a class="text-white" href="/">Point</a></li></ul></nav> <div class="flex flex-col items-center mt-[8rem]"><h1 class="text-green-400 text-4xl font-medium mb-[3rem]">AddPoint</h1> <input type="number" class="bg-white mb-2 p-2 rounded" placeholder="ID"${attr("value", Num)}> <input type="number" class="bg-white mb-[1.5rem] p-2 rounded" placeholder="Point"${attr("value", PointChange)}> <button class="bg-green-400 p-[0.5rem] px-[2rem] cursor-pointer rounded-md">ยืนยัน</button> <h1 class="text-red-400 text-4xl font-medium mt-[4.5rem] mb-[3rem]">DecreasePoint</h1> <input type="number" class="bg-white mb-2 p-2 rounded" placeholder="ID"${attr("value", Num)}> <input type="number" class="bg-white mb-[1.5rem] p-2 rounded" placeholder="Point"${attr("value", PointChange)}> <button class="bg-red-400 p-[0.5rem] px-[2rem] cursor-pointer rounded-md">ยืนยัน</button></div>`;
  pop();
}
export {
  _page as default
};
