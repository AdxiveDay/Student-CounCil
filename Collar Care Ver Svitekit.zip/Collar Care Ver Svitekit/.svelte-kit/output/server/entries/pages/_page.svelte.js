import { e as ensure_array_like, c as pop, p as push } from "../../chunks/index.js";
import { a as attr } from "../../chunks/attributes.js";
import { e as escape_html } from "../../chunks/escaping.js";
function _page($$payload, $$props) {
  push();
  let Detail = [];
  const each_array = ensure_array_like(Detail);
  $$payload.out += `<nav class="flex m-[3rem] items-center justify-between"><ul><h1 class="font-bold text-2xl w-[50px] text-blue-400">Student Council</h1></ul> <ul class="flex"><li class="mr-[1rem]"><a class="text-white" href="/">Point</a></li></ul></nav> <div class="flex flex-col items-center">`;
  if (Detail.length === 0) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<p class="text-red-500 mt-20">ไม่มีข้อมูล</p>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let item = each_array[$$index];
    $$payload.out += `<div class="w-[270px] h-[80px] items-center pl-[1rem] mt-[1rem] relative flex bg-[#1B1F2E] rounded-2xl"><img class="w-[50px] h-[50px] rounded-2xl"${attr("src", item.Pic)} alt=""> <div class="absolute left-[80px]"><h1 class="text-white font-medium text-[0.8rem]">${escape_html(item.name)}</h1> <h3 class="text-white text-[0.6rem] font-light">${escape_html(item.position)}</h3> <p class="text-white text-[0.6rem] font-light">${escape_html(item.class)}</p></div> <div class="absolute left-[178px]">`;
    if (item.point <= 50) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<h1 class="text-red-600 font-medium text-3xl ml-[1.5rem]">${escape_html(item.point)}</h1>`;
    } else {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<h1 class="text-white font-medium text-3xl ml-[1.5rem]">${escape_html(item.point)}</h1>`;
    }
    $$payload.out += `<!--]--></div></div>`;
  }
  $$payload.out += `<!--]--></div>`;
  pop();
}
export {
  _page as default
};
