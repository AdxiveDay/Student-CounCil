export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "internal",
	appPath: "Student-CounCil/internal",
	assets: new Set(["favicon.png"]),
	mimeTypes: {".png":"image/png"},
	_: {
		client: {start:"internal/immutable/entry/start.CbtIrutU.js",app:"internal/immutable/entry/app.DqUpUTkE.js",imports:["internal/immutable/entry/start.CbtIrutU.js","internal/immutable/chunks/C_DD_34h.js","internal/immutable/chunks/C5Wm2Csz.js","internal/immutable/chunks/DkJdufXc.js","internal/immutable/entry/app.DqUpUTkE.js","internal/immutable/chunks/C5Wm2Csz.js","internal/immutable/chunks/CRli0uGx.js","internal/immutable/chunks/DYiZZfqH.js","internal/immutable/chunks/DJ9hacb4.js","internal/immutable/chunks/D_0LPTat.js","internal/immutable/chunks/DkJdufXc.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js')),
			__memo(() => import('./nodes/4.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/IDmanage",
				pattern: /^\/IDmanage\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 4 },
				endpoint: null
			},
			{
				id: "/admin",
				pattern: /^\/admin\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
