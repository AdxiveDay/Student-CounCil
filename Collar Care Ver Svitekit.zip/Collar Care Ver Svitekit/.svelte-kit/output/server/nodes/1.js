

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["internal/immutable/nodes/1.BeJ9fTEa.js","internal/immutable/chunks/DJ9hacb4.js","internal/immutable/chunks/C5Wm2Csz.js","internal/immutable/chunks/CRli0uGx.js","internal/immutable/chunks/DYiZZfqH.js","internal/immutable/chunks/C_DD_34h.js","internal/immutable/chunks/DkJdufXc.js"];
export const stylesheets = [];
export const fonts = [];
