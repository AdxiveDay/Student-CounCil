

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["internal/immutable/nodes/0.C5ct6ZS4.js","internal/immutable/chunks/DJ9hacb4.js","internal/immutable/chunks/C5Wm2Csz.js"];
export const stylesheets = ["internal/immutable/assets/0.BrwOrDmG.css"];
export const fonts = [];
