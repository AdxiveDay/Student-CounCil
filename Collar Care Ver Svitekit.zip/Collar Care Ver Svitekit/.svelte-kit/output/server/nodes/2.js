

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["internal/immutable/nodes/2.FZwe67Ac.js","internal/immutable/chunks/DJ9hacb4.js","internal/immutable/chunks/C5Wm2Csz.js","internal/immutable/chunks/CRli0uGx.js","internal/immutable/chunks/DYiZZfqH.js","internal/immutable/chunks/D_0LPTat.js","internal/immutable/chunks/DtntkF14.js","internal/immutable/chunks/DkJdufXc.js"];
export const stylesheets = [];
export const fonts = [];
