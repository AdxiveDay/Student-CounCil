

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/admin/_page.svelte.js')).default;
export const imports = ["internal/immutable/nodes/3.B6jdWjBr.js","internal/immutable/chunks/DJ9hacb4.js","internal/immutable/chunks/C5Wm2Csz.js","internal/immutable/chunks/DYiZZfqH.js","internal/immutable/chunks/DtntkF14.js","internal/immutable/chunks/DIkibVnD.js","internal/immutable/chunks/DkJdufXc.js"];
export const stylesheets = [];
export const fonts = [];
